package com.tgf.user.personalaccountant;

import java.util.ArrayList;

/**
 * Created by Akropon on 28.01.2017.
 */

public class Calculation {

    public String name;
    public ArrayList<Device> devicesList;
    public double tariff;     // стоимость в Денежных Единицах одного кВ*часа
    public double period_num; // временной период (количественная характеристика)
    public int period_vlt;    // временной период (величина измерения)

    public Calculation() {
        name = "noname";
        devicesList = new ArrayList<Device>();
        tariff = 0;
        period_num = 0;
        period_vlt = 0;
    }



    /** Стоимость (в Денежных Единицах) электроэнергии, потраченной всеми приборами в расчете при указанном Тарифе.
     *
     *
     * Тариф - стоимость (в Денежных Единицах) одного кВт-час
     * Выбор Денежной Единицы не влияет на результат выполнения функции.
     * Возвращаемая стоимость электроэнергии будет выражаться в тех же Денежных Единицах,
     * в которых указан Тариф.
     *
     * @return (double) - стоимость (в Денежных Единицах)
     */
    public double get_cost() {
        if (devicesList.size() == 0 || tariff == 0 || period_num == 0)
            return 0;
        double cost = 0;
        for (Device device : devicesList) {  // конструкция типа "foreach"
            cost += device.get_cost(tariff, period_num, period_vlt);
        }
        return cost;
    }
}
