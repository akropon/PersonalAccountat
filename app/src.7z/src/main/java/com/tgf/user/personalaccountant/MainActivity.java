package com.tgf.user.personalaccountant;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    ImageView imageView;
    Button butGo;
    Button butSetting;
    Button butQuit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = (ImageView) findViewById(R.id.imageView);
        imageView.setImageResource(R.drawable.picture);

        butGo = (Button) findViewById(R.id.button);
        butSetting = (Button) findViewById(R.id.button2);
        butQuit = (Button) findViewById(R.id.button3);

    }

    public void onClick(View v) {// Функция обработчик нажатия трех кнопок


        switch(v.getId()) {
            case R.id.button:
                Intent intent=new Intent(this,Podr.class);// Переходим на счет
                startActivityForResult(intent,1);
                break;
            case R.id.button2:
                Intent intent1=new Intent(this,Settings.class);// Переходим на настройки
                startActivityForResult(intent1,1);
                break;
            case R.id.button3:
                finish();
                break;


        }


    }

}
