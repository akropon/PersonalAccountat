package com.tgf.user.personalaccountant;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class Podr extends AppCompatActivity {



    CheckBox checkBox;
    EditText textName;
    EditText textTarif;
    EditText textTime;
    EditText textPower;
    EditText KolvoPr;

    TextView textView;
    TextView textView6;

    Spinner spinner1;
    Spinner spinner2;
    Spinner spinner3;
    Spinner spinner4;

    ArrayAdapter<String> adapter1;
    ArrayAdapter<String> adapter2;
    ArrayAdapter<String> adapter3;
    ArrayAdapter<String> adapter4;

    final String[] periodsRaschet = new String[] {
            "Минута", "Час","Сутки", "Месяц", "Год"
    };

    final String[] powerVariati = new String[] {
            "Вт", "кВт"
    };

    final String[] timeWork = new String[] {
            "Минута", "Час","Сутки", "Месяц", "Год"
    };

    final String[] peridTimeWork = new String[] {
             "Сутки","Неделя", "Месяц", "Год"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_podr);

        checkBox = (CheckBox) findViewById(R.id.checkBox);
        checkBox.setChecked(true);

        textName = (EditText) findViewById(R.id.editText);
        textTarif = (EditText) findViewById(R.id.editText2);
        textTime =  (EditText) findViewById(R.id.editText3);
        textPower =  (EditText)findViewById(R.id.editText4);
        KolvoPr = (EditText) findViewById(R.id.editText5);

        textView =  (TextView) findViewById(R.id.textView3);
        textView6 = (TextView) findViewById(R.id.textView6);

        spinner1 = (Spinner) findViewById(R.id.spinner);
        spinner2 = (Spinner) findViewById(R.id.spinner2);
        spinner3 = (Spinner) findViewById(R.id.spinner3);
        spinner4 = (Spinner) findViewById(R.id.spinner4);



        adapter1 = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, periodsRaschet);
        adapter2 = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, powerVariati);
        adapter3 = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, timeWork);
        adapter4 = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, peridTimeWork);

        spinner1.setAdapter(adapter1);
        spinner2.setAdapter(adapter2);
        spinner3.setAdapter(adapter3);
        spinner4.setAdapter(adapter4);

    }

    public void onClicker(View v) {// Функция обработчик нажатия трех кнопок

        if(!checkBox.isChecked()) {

            textName.setEnabled(false);



            textView.setEnabled(false);
            textView.setCursorVisible(false);


        }
        else
        {
            textName.setEnabled(true);



            textView.setEnabled(true);
            textView.setCursorVisible(true);

        }
        switch(v.getId()) {
            case R.id.button4:
                Intent intent=new Intent(this,MainActivity.class);// Переходим назад
                startActivityForResult(intent,1);
                break;
            case R.id.button9:
                Intent intent1=new Intent(this,Jurnal.class);// Переходим в журнал
                startActivityForResult(intent1,1);
                break;
            case R.id.button5:

                float power = 0;
                float period = 0;
                float timework = 0;
                float tarif = 0;
                float result = 0;
                int kolvo =0;

                // Проверка на пустоту
                if (TextUtils.isEmpty(textTarif.getText().toString()) || TextUtils.isEmpty(textTime.getText().toString()) || TextUtils.isEmpty(textPower.getText().toString()))
                {
                    return;
                }

                // Читаем EditText
                power = Float.parseFloat(textPower.getText().toString());
                period = Float.parseFloat(textTime.getText().toString());
                tarif = Float.parseFloat(textTarif.getText().toString());
                kolvo = Integer.parseInt(KolvoPr.getText().toString());

                String bufferForPerevod = spinner1.getSelectedItem().toString();
                switch (bufferForPerevod)
                {
                    case "Минута":
                        period= (float) (period*0.0167);
                        break;
                    case "Час":
                        break;
                    case "Сутки":
                        period=period*24;
                        break;
                    case "Месяц":
                        period= period*720;
                        break;
                    case "Год":
                        period=period*8760;
                        break;


                }
                bufferForPerevod =spinner2.getSelectedItem().toString();
                switch (bufferForPerevod)
                {
                    case "Вт":
                        power= (float) (power*0.001);
                        break;
                    case "кВт":
                        break;

                }
                /*bufferForPerevod =spinner3.getSelectedItem().toString();
                switch (bufferForPerevod)
                {
                    case "Минута":
                        period= (float) (period*0.0167);
                        break;
                    case "Час":
                        break;
                    case "Сутки":
                        period=period*24;
                        break;
                    case "Месяц":
                        period= period*720;
                        break;
                    case "Год":
                        period=period*8760;
                        break;


                }
                bufferForPerevod =spinner4.getSelectedItem().toString();
                switch (bufferForPerevod)
                {
                    case "Минута":
                        period= (float) (period*0.0167);
                        break;
                    case "Час":
                        break;
                    case "Сутки":
                        period=period*24;
                        break;
                    case "Месяц":
                        period= period*720;
                        break;
                    case "Год":
                        period=period*8760;
                        break;


                }*/






                result = ((power*period)/tarif)*kolvo;

                // формируем строку вывода
                textView6.setText(result+"");
                break;


        }


    }


}
