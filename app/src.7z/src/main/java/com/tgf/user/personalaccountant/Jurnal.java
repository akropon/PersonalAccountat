package com.tgf.user.personalaccountant;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseExpandableListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class Jurnal extends AppCompatActivity {

    ListView listViewJournal;
    //ArrayList<HashMap<String, String>> journal=new ArrayList<HashMap<String, String>>();
   // ArrayAdapter<String> adapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jurnal);

        listViewJournal = (ListView) findViewById(R.id.listView);
        loadAdapter();
    }


    private void loadAdapter() {

        Calculation calculation = new Calculation();
        calculation.name = "calc_name1";
        calculation.period_num = 2;
        calculation.period_vlt = ValueTypes.HOUR;
        calculation.tariff = 5;

        calculation.devicesList.add(
                new Device(
                        "Лампа-хуямпа",
                        40, ValueTypes.W,
                        2,
                        5, ValueTypes.HOUR, ValueTypes.DAY));
        calculation.devicesList.add(
                new Device(
                        "Холодульник",
                        10, ValueTypes.W,
                        1,
                        24, ValueTypes.HOUR, ValueTypes.DAY));
        calculation.devicesList.add(
                new Device(
                        "Пылесос",
                        2, ValueTypes.kW,
                        1,
                        1, ValueTypes.HOUR, ValueTypes.WEEK));

        CalculationAdapter calc_adapter = new CalculationAdapter(this, calculation);
        listViewJournal.setAdapter(calc_adapter);

        //adapter = new ArrayAdapter<HashMap>(this, R.layout.list_item, journal);
        //listViewJournal.setAdapter(adapter);

        /*listViewMemory.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(wantDelete == true)
                {
                    memory.remove(parent.getItemAtPosition(position));
                    adapter1.notifyDataSetChanged();
                    //Toast.makeText(getBaseContext(),"To end of removing - push button DELETE",Toast.LENGTH_SHORT).show();

                }
                else
                {
                    Intent intent1 = new Intent();
                    intent1.putExtra("answer", ((TextView) view).getText());
                    setResult(RESULT_OK, intent1);
                    finish();
                }
            }
        });*/
        /*View.OnClickListener onClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (view.getId()){
                    case R.id.buttonAdd:
                        if(memory.size()<11) {
                            memory.add(0, journal.get(0).toString());
                            adapter1.notifyDataSetChanged();
                        }
                        else
                        {
                            Toast.makeText(getBaseContext(),"Cannot to add, memory is overflow",Toast.LENGTH_SHORT).show();
                        }
                        break;
                    case R.id.buttonDelete:
                        switch (amountClick) {
                            case 0:
                                wantDelete=true;
                                Toast.makeText(getBaseContext(),"To delete from memory push on items in list",Toast.LENGTH_SHORT).show();
                                buttonDelete.setTextColor(Color.GREEN);
                                amountClick = 1;

                                break;
                            case 1:

                                wantDelete=false;
                                buttonDelete.setTextColor(Color.WHITE);
                                amountClick = 0;
                                break;
                        }
                        break;
                }
            }
        };
        buttonAdd.setOnClickListener(onClickListener);
        buttonDelete.setOnClickListener(onClickListener);*/
    }
}
